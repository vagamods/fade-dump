using BepInEx;
using UnityEngine;
using UnityEngine.InputSystem;

namespace InjectedModDumper;

[BepInPlugin(Constants.Guid, Constants.Name, Constants.Version)]
public class Plugin : BaseUnityPlugin
{
    private void Start()
    {
        Dumper.Init(Logger);
        Dumper.DumpAll("auto");
        Logger.LogInfo($"[{Constants.Name}] loaded — F9 to re-dump");
    }

    private void Update()
    {
        if (Keyboard.current != null && Keyboard.current[Key.F9].wasPressedThisFrame)
            Dumper.DumpAll("manual");
    }
}
