using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Logging;
using HarmonyLib;

namespace InjectedModDumper;

internal static class Dumper
{
    private static ManualLogSource _log = null!;
    private static string _dumpDir = "";

    private static readonly HashSet<string> KnownSkip = new(StringComparer.OrdinalIgnoreCase)
    {
        "mscorlib", "System", "System.Core", "System.Xml",
        "System.Configuration", "System.Security",
        "UnityEngine", "UnityEngine.CoreModule", "UnityEngine.UIModule",
        "UnityEngine.AudioModule", "UnityEngine.PhysicsModule",
        "UnityEngine.AnimationModule", "UnityEngine.TextRenderingModule",
        "UnityEngine.InputLegacyModule", "UnityEngine.VRModule",
        "UnityEngine.XRModule", "UnityEngine.AssetBundleModule",
        "UnityEngine.ParticleSystemModule", "UnityEngine.TerrainModule",
        "UnityEngine.ImageConversionModule",
        "BepInEx", "BepInEx.Harmony", "BepInEx.Preloader",
        "BepInEx.Bootstrap", "BepInEx.Core",
        "0Harmony", "MonoMod.RuntimeDetour", "MonoMod.Utils",
        "Mono.Cecil", "Mono.Security",
        "netstandard", "Microsoft.CSharp",
    };

    // ── init ──────────────────────────────────────────────────────────────

    internal static void Init(ManualLogSource log)
    {
        _log     = log;
        _dumpDir = Path.Combine(Paths.BepInExRootPath, "dumps");
        Directory.CreateDirectory(_dumpDir);
    }

    // ── core ──────────────────────────────────────────────────────────────

    internal static void DumpAll(string trigger)
    {
        string stamp    = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string baseName = $"injected_dump_{trigger}_{stamp}";

        var bep       = CollectBepInEx();
        var inj       = CollectInjected(bep);
        var native    = CollectNative();
        var patches   = CollectHarmony();
        var wyvernProc = CheckWyvernProcess();

        WriteJson(Path.Combine(_dumpDir, baseName + ".json"), bep, inj, native, patches, wyvernProc, trigger, stamp);
        WriteTxt (Path.Combine(_dumpDir, baseName + ".txt"),  bep, inj, native, patches, wyvernProc, trigger, stamp);

        _log.LogInfo(
            $"bepinex:{bep.Count}  injected:{inj.Count}  " +
            $"native:{native.Count}  patches:{patches.Count}  " +
            $"wyvern_process:{wyvernProc}  → {_dumpDir}");
    }

    // ── collectors ────────────────────────────────────────────────────────

    private static List<BepPlugin> CollectBepInEx()
    {
        var list = new List<BepPlugin>();
        foreach (var kv in Chainloader.PluginInfos)
        {
            var info = kv.Value;
            var meta = info.Metadata;
            string loc = "", asmFull = "", asmShort = "";
            try
            {
                var a = info.Instance?.GetType().Assembly;
                if (a != null) { loc = a.Location; asmFull = a.FullName!; asmShort = a.GetName().Name!; }
            }
            catch { }

            var depList = new List<string>();
            try { foreach (var d in info.Dependencies) depList.Add($"{d.DependencyGUID}>={d.MinimumVersion}"); }
            catch { }

            list.Add(new BepPlugin
            {
                Guid = meta.GUID, Name = meta.Name, Version = meta.Version.ToString(),
                Location = loc, AsmFull = asmFull, AsmShort = asmShort,
                HasInstance  = info.Instance != null,
                Dependencies = string.Join(", ", depList),
            });
        }
        return list;
    }

    private static List<InjectedEntry> CollectInjected(List<BepPlugin> bep)
    {
        var list    = new List<InjectedEntry>();
        var bepNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var b in bep) bepNames.Add(b.AsmShort);

        foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
        {
            try
            {
                string shortName = asm.GetName().Name!;
                if (ShouldSkip(shortName) || bepNames.Contains(shortName)) continue;

                string loc = "";
                try { loc = asm.Location; } catch { }
                bool isDynamic  = asm.IsDynamic;
                bool isInMemory = !isDynamic && string.IsNullOrEmpty(loc);
                // isInMemory = true means loaded from bytes at runtime (injector pattern)

                // probe entry-point signatures
                string ep = "";
                var types = SafeTypes(asm);
                foreach (var t in types)
                {
                    foreach (var sig in new[] { "Init", "Load", "Main", "Start", "OnLoad", "Initialize", "Entry" })
                    {
                        if (t.GetMethod(sig,
                            BindingFlags.Public | BindingFlags.NonPublic |
                            BindingFlags.Static | BindingFlags.Instance) is { } m)
                        { ep = $"{t.FullName}.{m.Name}"; break; }
                    }
                    if (ep != "") break;
                }

                // harmony attribute scan
                bool hasHarmony = false;
                foreach (var t in types)
                    if (t.GetCustomAttributes(typeof(HarmonyPatch), true).Length > 0)
                    { hasHarmony = true; break; }

                // for suspicious in-memory assemblies: dump every public type name
                // this is how we profile what a packed injector (like Wyvern) drops
                var typeNames = new List<string>();
                if (isInMemory || isDynamic)
                {
                    foreach (var t in types)
                        if (t?.FullName != null)
                            typeNames.Add(t.FullName);
                }

                // wyvern probe — by type name patterns since binary is packed
                string wyvernMeta = ProbeWyvern(asm, types);

                list.Add(new InjectedEntry
                {
                    ShortName  = shortName,
                    FullName   = asm.FullName ?? "",
                    Location   = isDynamic   ? "[dynamic]"   :
                                 isInMemory  ? "[in-memory — injected]" : loc,
                    IsDynamic  = isDynamic,
                    IsInMemory = isInMemory,
                    EntryPoint = ep,
                    HasHarmony = hasHarmony,
                    WyvernMeta = wyvernMeta,
                    TypeCount  = types.Length,
                    TypeNames  = typeNames,
                });
            }
            catch { }
        }
        return list;
    }

    private static List<NativeModule> CollectNative()
    {
        var list = new List<NativeModule>();
        var skip = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "UnityPlayer.dll", "mono-2.0-bdwgc.dll", "ntdll.dll",
            "kernel32.dll", "kernelbase.dll", "user32.dll", "gdi32.dll",
            "advapi32.dll", "ole32.dll", "shell32.dll", "winmm.dll",
            "d3d11.dll", "dxgi.dll", "opengl32.dll",
            "steam_api64.dll", "steamclient64.dll",
            "tier0_s64.dll", "vstdlib_s64.dll",
        };
        try
        {
            foreach (ProcessModule mod in Process.GetCurrentProcess().Modules)
            {
                string fname = Path.GetFileName(mod.FileName);
                if (skip.Contains(fname)) continue;
                if (fname.StartsWith("msvc",     StringComparison.OrdinalIgnoreCase)) continue;
                if (fname.StartsWith("Windows.", StringComparison.OrdinalIgnoreCase)) continue;
                list.Add(new NativeModule
                {
                    Name     = fname,
                    Path     = mod.FileName,
                    BaseAddr = $"0x{mod.BaseAddress.ToInt64():X16}",
                    SizeKB   = mod.ModuleMemorySize / 1024,
                });
            }
        }
        catch (Exception ex) { _log.LogWarning($"native scan partial: {ex.Message}"); }
        return list;
    }

    private static List<PatchEntry> CollectHarmony()
    {
        var list = new List<PatchEntry>();
        try
        {
            foreach (var method in Harmony.GetAllPatchedMethods())
            {
                var pi  = Harmony.GetPatchInfo(method);
                string tgt = $"{method.DeclaringType?.FullName}.{method.Name}";
                foreach (var p in pi.Prefixes)    list.Add(new PatchEntry { Kind = "prefix",     Owner = p.owner, Target = tgt });
                foreach (var p in pi.Postfixes)   list.Add(new PatchEntry { Kind = "postfix",    Owner = p.owner, Target = tgt });
                foreach (var p in pi.Transpilers) list.Add(new PatchEntry { Kind = "transpiler", Owner = p.owner, Target = tgt });
                foreach (var p in pi.Finalizers)  list.Add(new PatchEntry { Kind = "finalizer",  Owner = p.owner, Target = tgt });
            }
        }
        catch { }
        return list;
    }

    // ── Wyvern process check ──────────────────────────────────────────────
    // WyvernLoader is a native packed injector — look for it running
    // as a separate process or for its injected module in the game's list

    private static string CheckWyvernProcess()
    {
        try
        {
            // check if WyvernLoader is a running process on the machine
            var procs = Process.GetProcessesByName("WyvernLoader");
            if (procs.Length > 0)
                return $"running (pid:{procs[0].Id})";

            // also check if anything wyvern-named is in our own module list
            foreach (ProcessModule mod in Process.GetCurrentProcess().Modules)
            {
                string name = Path.GetFileName(mod.FileName);
                if (name.IndexOf("wyvern", StringComparison.OrdinalIgnoreCase) >= 0)
                    return $"module_in_process:{name}@0x{mod.BaseAddress.ToInt64():X}";
            }
        }
        catch { }
        return "not_detected";
    }

    // ── Wyvern assembly probe ─────────────────────────────────────────────
    // Binary is packed so we can't get type names statically.
    // At runtime, the injected payload IS a .NET assembly — probe it
    // by field/method patterns that any mod framework exposes.

    private static string ProbeWyvern(Assembly asm, Type[] types)
    {
        // explicit type name candidates (extend if Wyvern's payload uses these)
        var candidates = new[]
        {
            "WyvernLoader.ModManager", "WyvernLoader.Loader", "WyvernLoader.Core",
            "WyvernLoader.Main",       "Wyvern.ModManager",   "Wyvern.Core",
            "WyvernLoader.Plugin",     "WyvernLoader.Mod",
        };
        foreach (var typeName in candidates)
        {
            try
            {
                var t = asm.GetType(typeName);
                if (t == null) continue;
                foreach (var fn in new[] { "ModName", "Name", "Version", "ModVersion", "ID", "Guid" })
                {
                    var fi = t.GetField(fn,
                        BindingFlags.Public | BindingFlags.NonPublic |
                        BindingFlags.Static | BindingFlags.Instance);
                    if (fi != null) return $"{typeName}.{fn}={fi.GetValue(null)}";
                    var pi = t.GetProperty(fn,
                        BindingFlags.Public | BindingFlags.NonPublic |
                        BindingFlags.Static | BindingFlags.Instance);
                    if (pi != null) return $"{typeName}.{fn}={pi.GetValue(null)}";
                }
                return $"[type found: {typeName}]";
            }
            catch { }
        }

        // fallback: for in-memory assemblies, scan every type for
        // "wyvern" or "mod" in the namespace/name — catches obfuscated payloads
        foreach (var t in types)
        {
            if (t?.FullName == null) continue;
            string fn = t.FullName.ToLower();
            if (fn.Contains("wyvern") || fn.Contains("wyvernloader"))
                return $"[type name match: {t.FullName}]";
        }

        return "";
    }

    // ── helpers ───────────────────────────────────────────────────────────

    private static Type[] SafeTypes(Assembly asm)
    {
        try { return asm.GetTypes(); }
        catch (ReflectionTypeLoadException ex) { return ex.Types ?? Array.Empty<Type>(); }
        catch { return Array.Empty<Type>(); }
    }

    private static bool ShouldSkip(string name)
    {
        if (KnownSkip.Contains(name)) return true;
        foreach (var pfx in new[] { "System.", "Microsoft.", "Unity.", "UnityEngine.", "Photon." })
            if (name.StartsWith(pfx, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    private static string Esc(string? s) =>
        (s ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");

    // ── JSON writer ───────────────────────────────────────────────────────

    private static void WriteJson(
        string path,
        List<BepPlugin> bep, List<InjectedEntry> inj,
        List<NativeModule> native, List<PatchEntry> patches,
        string wyvernProc, string trigger, string stamp)
    {
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine($"  \"dump_trigger\": \"{trigger}\",");
        sb.AppendLine($"  \"dump_time\": \"{stamp}\",");
        sb.AppendLine($"  \"wyvern_process\": \"{wyvernProc}\",");

        // bepinex
        sb.AppendLine("  \"bepinex_plugins\": [");
        for (int i = 0; i < bep.Count; i++)
        {
            var p = bep[i];
            sb.AppendLine($"    {{ \"guid\": \"{Esc(p.Guid)}\", \"name\": \"{Esc(p.Name)}\", " +
                          $"\"version\": \"{Esc(p.Version)}\", \"has_instance\": {p.HasInstance.ToString().ToLower()}, " +
                          $"\"location\": \"{Esc(p.Location)}\", \"deps\": \"{Esc(p.Dependencies)}\" }}{(i < bep.Count-1?",":"")}");
        }
        sb.AppendLine("  ],");

        // injected
        sb.AppendLine("  \"injected_assemblies\": [");
        for (int i = 0; i < inj.Count; i++)
        {
            var e = inj[i];
            sb.AppendLine("    {");
            sb.AppendLine($"      \"name\": \"{Esc(e.ShortName)}\",");
            sb.AppendLine($"      \"full\": \"{Esc(e.FullName)}\",");
            sb.AppendLine($"      \"location\": \"{Esc(e.Location)}\",");
            sb.AppendLine($"      \"dynamic\": {e.IsDynamic.ToString().ToLower()},");
            sb.AppendLine($"      \"in_memory\": {e.IsInMemory.ToString().ToLower()},");
            sb.AppendLine($"      \"types\": {e.TypeCount},");
            sb.AppendLine($"      \"entry\": \"{Esc(e.EntryPoint)}\",");
            sb.AppendLine($"      \"harmony\": {e.HasHarmony.ToString().ToLower()},");
            sb.AppendLine($"      \"wyvern\": \"{Esc(e.WyvernMeta)}\",");
            // dump type list for in-memory assemblies — this is the payload manifest
            if (e.TypeNames.Count > 0)
            {
                sb.Append("      \"type_list\": [");
                sb.Append(string.Join(", ", e.TypeNames.ConvertAll(t => $"\"{Esc(t)}\"")));
                sb.AppendLine("]");
            }
            else sb.AppendLine("      \"type_list\": []");
            sb.Append("    }");
            sb.AppendLine(i < inj.Count-1 ? "," : "");
        }
        sb.AppendLine("  ],");

        // native
        sb.AppendLine("  \"native_modules\": [");
        for (int i = 0; i < native.Count; i++)
        {
            var n = native[i];
            sb.AppendLine($"    {{ \"name\": \"{Esc(n.Name)}\", \"path\": \"{Esc(n.Path)}\", " +
                          $"\"base\": \"{n.BaseAddr}\", \"size_kb\": {n.SizeKB} }}{(i < native.Count-1?",":"")}");
        }
        sb.AppendLine("  ],");

        // harmony
        sb.AppendLine("  \"harmony_patches\": [");
        for (int i = 0; i < patches.Count; i++)
        {
            var h = patches[i];
            sb.AppendLine($"    {{ \"kind\": \"{h.Kind}\", \"owner\": \"{Esc(h.Owner)}\", " +
                          $"\"target\": \"{Esc(h.Target)}\" }}{(i < patches.Count-1?",":"")}");
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
    }

    // ── TXT writer ────────────────────────────────────────────────────────

    private static void WriteTxt(
        string path,
        List<BepPlugin> bep, List<InjectedEntry> inj,
        List<NativeModule> native, List<PatchEntry> patches,
        string wyvernProc, string trigger, string stamp)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"=== InjectedModDumper  trigger:{trigger}  time:{stamp} ===");
        sb.AppendLine($"Wyvern process: {wyvernProc}");

        sb.AppendLine($"\n── BepInEx plugins ({bep.Count}) ──────────────────────────────");
        foreach (var p in bep)
        {
            sb.AppendLine($"  GUID     : {p.Guid}");
            sb.AppendLine($"  Name     : {p.Name}  v{p.Version}");
            sb.AppendLine($"  Instance : {(p.HasInstance ? "live" : "NULL")}");
            sb.AppendLine($"  Location : {p.Location}");
            if (!string.IsNullOrEmpty(p.Dependencies)) sb.AppendLine($"  Deps     : {p.Dependencies}");
            sb.AppendLine();
        }

        sb.AppendLine($"\n── Injected assemblies ({inj.Count}) ──────────────────────────");
        foreach (var e in inj)
        {
            sb.AppendLine($"  Assembly   : {e.ShortName}");
            sb.AppendLine($"  Full name  : {e.FullName}");
            sb.AppendLine($"  Location   : {e.Location}");
            sb.AppendLine($"  Dynamic    : {e.IsDynamic}  InMemory: {e.IsInMemory}  Types: {e.TypeCount}");
            if (!string.IsNullOrEmpty(e.EntryPoint)) sb.AppendLine($"  EntryPoint : {e.EntryPoint}");
            if (e.HasHarmony)                        sb.AppendLine($"  Harmony    : YES");
            if (!string.IsNullOrEmpty(e.WyvernMeta)) sb.AppendLine($"  Wyvern     : {e.WyvernMeta}");
            if (e.TypeNames.Count > 0)
            {
                sb.AppendLine($"  Types (in-memory payload):");
                foreach (var tn in e.TypeNames) sb.AppendLine($"    {tn}");
            }
            sb.AppendLine();
        }

        sb.AppendLine($"\n── Native modules ({native.Count}) ────────────────────────────");
        foreach (var n in native)
            sb.AppendLine($"  {n.Name,-35} base:{n.BaseAddr}  size:{n.SizeKB}KB");

        sb.AppendLine($"\n── Harmony patches ({patches.Count}) ───────────────────────────");
        foreach (var h in patches)
            sb.AppendLine($"  [{h.Kind,-11}] {h.Owner,-30} → {h.Target}");

        File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
    }

    // ── shapes ────────────────────────────────────────────────────────────

    private record BepPlugin
    {
        public string Guid = "", Name = "", Version = "", Location = "";
        public string AsmFull = "", AsmShort = "", Dependencies = "";
        public bool   HasInstance;
    }

    private record InjectedEntry
    {
        public string       ShortName = "", FullName = "", Location = "", EntryPoint = "", WyvernMeta = "";
        public bool         IsDynamic, IsInMemory, HasHarmony;
        public int          TypeCount;
        public List<string> TypeNames = new();
    }

    private record NativeModule
    {
        public string Name = "", Path = "", BaseAddr = "";
        public int    SizeKB;
    }

    private record PatchEntry
    {
        public string Kind = "", Owner = "", Target = "";
    }
}
