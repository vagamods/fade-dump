namespace InjectedModDumper;

public static class Constants
{
    public const string Name    = "InjectedModDumper";
    public const string Guid    = "com.ramen.injectedmoddumper";
    public const string Version = "1.0.0";
}
